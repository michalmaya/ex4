//
// Created by michalmaya on 17/06/2022.
//

#include "Goblin.h"

Goblin::Goblin() : Battle("Goblin", 10, 2, 6)
{}